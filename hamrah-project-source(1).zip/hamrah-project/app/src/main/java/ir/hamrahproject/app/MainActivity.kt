package ir.hamrahproject.app

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.platform.LocalLayoutDirection
import androidx.compose.ui.unit.LayoutDirection

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { MaterialTheme { CompositionLocalProvider(LocalLayoutDirection provides LayoutDirection.Rtl) { HomeScreen() } } }
    }
}

@Composable
fun HomeScreen() {
    var projectName by remember { mutableStateOf("احداث مخزن بتنی ۲۰۰۰ مترمکعبی") }
    var newTask by remember { mutableStateOf("") }
    val tasks = remember { mutableStateListOf("مطالعات و تجهیز کارگاه", "خاک‌برداری", "بتن مگر", "آرماتوربندی و بتن‌ریزی کف", "اجرای دیوارها", "اجرای سقف", "آب‌بندی و نصب لوله‌ها", "تست و تحویل") }
    var selected by remember { mutableStateOf("داشبورد") }
    Scaffold(topBar = { TopAppBar(title = { Text("همراه پروژه") }) }) { padding ->
        LazyColumn(Modifier.fillMaxSize().padding(padding).padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
            item {
                Text("سامانه مدیریت و کنترل پروژه", style = MaterialTheme.typography.titleMedium)
                OutlinedTextField(value = projectName, onValueChange = { projectName = it }, label = { Text("نام پروژه") }, modifier = Modifier.fillMaxWidth())
            }
            item {
                Card(Modifier.fillMaxWidth()) {
                    Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                        Text("داشبورد پروژه", style = MaterialTheme.typography.titleLarge)
                        Text("پیشرفت نمونه: 0٪")
                        LinearProgressIndicator(progress = { 0f }, modifier = Modifier.fillMaxWidth())
                        Text("فعالیت‌ها: ${tasks.size}")
                        Text("وضعیت: پروژه نمونه؛ اطلاعات نیازمند تأیید کاربر")
                    }
                }
            }
            item {
                Text("بخش‌های اصلی", style = MaterialTheme.typography.titleMedium)
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    listOf("داشبورد", "فعالیت‌ها", "اسناد", "گزارش‌ها").forEach { label ->
                        FilterChip(selected = selected == label, onClick = { selected = label }, label = { Text(label) })
                    }
                }
            }
            item { Text("فعالیت‌های پروژه", style = MaterialTheme.typography.titleMedium) }
            items(tasks) { task ->
                Card(Modifier.fillMaxWidth()) {
                    Row(Modifier.padding(12.dp), verticalAlignment = Alignment.CenterVertically) {
                        Text(task, modifier = Modifier.weight(1f), textAlign = TextAlign.Start)
                        Text("ثبت‌نشده")
                    }
                }
            }
            item {
                OutlinedTextField(value = newTask, onValueChange = { newTask = it }, label = { Text("فعالیت جدید") }, modifier = Modifier.fillMaxWidth())
                Button(onClick = { if (newTask.isNotBlank()) { tasks.add(newTask.trim()); newTask = "" } }, modifier = Modifier.fillMaxWidth()) { Text("افزودن فعالیت") }
            }
            item { Text("نسخه پایه آزمایشی — قابلیت‌های تحلیل هوشمند اسناد، زمان‌بندی پیشرفته و همگام‌سازی هنوز به این نسخه اضافه نشده‌اند.", style = MaterialTheme.typography.bodySmall) }
        }
    }
}
